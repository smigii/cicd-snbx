#!/bin/sh

kubectl --help
aws --version
vault --version
terraform --version
helm --help